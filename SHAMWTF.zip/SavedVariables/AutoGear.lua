
AutoGearDB = {
	["Enabled"] = true,
	["Override"] = false,
	["AutoAcceptPartyInvitations"] = true,
	["AutoAcceptQuests"] = true,
	["PawnScale"] = "",
	["RollOnNonGearLoot"] = true,
	["AutoRepair"] = true,
	["AllowedVerbosity"] = 2,
	["ScoreInTooltips"] = true,
	["ReasonsInTooltips"] = false,
	["AutoConfirmBinding"] = true,
	["AutoSellGreys"] = true,
	["UsePawn"] = false,
	["OverridePawnScale"] = true,
	["OverrideSpec"] = "Shaman: None",
	["AutoLootRoll"] = true,
}
