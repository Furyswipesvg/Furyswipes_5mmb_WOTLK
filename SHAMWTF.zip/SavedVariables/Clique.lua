
CliqueDB = {
	["char"] = {
	},
	["profileKeys"] = {
		["Jealousy - LichKingMBW"] = "Jealousy - LichKingMBW",
		["Deathstrike - LichKingMBW"] = "Deathstrike - LichKingMBW",
		["Yogi - LichKingMBW"] = "Yogi - LichKingMBW",
		["Furyswipes - LichKingMBW"] = "Furyswipes - LichKingMBW",
	},
	["profiles"] = {
		["Jealousy - LichKingMBW"] = {
		},
		["Deathstrike - LichKingMBW"] = {
		},
		["Yogi - LichKingMBW"] = {
		},
		["Furyswipes - LichKingMBW"] = {
		},
	},
}
