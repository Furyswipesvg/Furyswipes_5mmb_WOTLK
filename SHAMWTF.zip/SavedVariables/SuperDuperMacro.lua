
sdm_version = "1.8.3"
sdm_listFilters = {
	["true"] = true,
	["s"] = true,
	["b"] = true,
	["false"] = true,
	["global"] = true,
	["f"] = true,
}
sdm_iconSize = 36
sdm_mainContents = {
	5, -- [1]
	8, -- [2]
	4, -- [3]
	10, -- [4]
	3, -- [5]
	6, -- [6]
	1, -- [7]
	2, -- [8]
	0, -- [9]
	9, -- [10]
	7, -- [11]
	33, -- [12]
	34, -- [13]
	35, -- [14]
	36, -- [15]
	37, -- [16]
	38, -- [17]
	39, -- [18]
	40, -- [19]
	41, -- [20]
	42, -- [21]
}
sdm_macros = {
	{
		["type"] = "f",
		["name"] = "BLOOD_AUX1",
		["ID"] = 1,
		["text"] = "# Enter macro text here\n/cast mark of blood",
		["icon"] = 1,
	}, -- [1]
	{
		["type"] = "f",
		["name"] = "BLOOD_AUX2",
		["ID"] = 2,
		["text"] = "# Enter macro text here.\n/cast death coil",
		["icon"] = 1,
	}, -- [2]
	{
		["type"] = "f",
		["name"] = "BEAR_TANK_SINGLE",
		["ID"] = 3,
		["text"] = "# Enter macro text here.\n/cast [nostance:1] dire bear form\n/startattack [nomod] \n/cast [nomod] faerie fire (feral)\n/cast [nomod] enrage\n/cast [nomod] feral charge - bear\n/castsequence reset=combat [nomod] maul,,,,,,,,,,,,,,,,,,,,,,,,,maul,,,,,,,,,,,,,,,,,,,,,,\n/cast [mod:alt] growl\n\n",
		["icon"] = 1,
	}, -- [3]
	{
		["type"] = "f",
		["name"] = "BEAR_TANK_MULTI",
		["ID"] = 4,
		["text"] = "# Enter macro text here.\n# Enter macro text here.\n/cast [nostance:1] dire bear form\n/startattack [nomod] \n/cast [nomod] enrage\n/cast [nomod] feral charge - bear\n/cast [nomod] mangle (bear)\n\n/cast [nomod] swipe (bear)\n\n",
		["icon"] = 1,
	}, -- [4]
	{
		["type"] = "f",
		["name"] = "BEAR_TANK_AOE",
		["ID"] = 5,
		["text"] = "\n/cast [nostance:1] dire bear form\n/startattack [nomod] \n/cast [nomod] enrage\n/cast [nomod] feral charge - bear\n/cast [nomod] mangle (bear)\n\n/cast [nomod] swipe (bear)\n\n",
		["icon"] = 1,
	}, -- [5]
	{
		["type"] = "f",
		["name"] = "BEAR_TANK_TURBO",
		["ID"] = 6,
		["text"] = "# Enter macro text here.\n/cancelform [stance,mod:ctrl]\n/cast [mod:ctrl,nostance] flight form\n/cast [combat,nomod] berserk",
		["icon"] = 1,
	}, -- [6]
	{
		["type"] = "b",
		["name"] = "DELAY",
		["ID"] = 7,
		["text"] = "# Enter macro text here.\n\n/castsequence [nomod] reset=combat maul,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,maul,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,maul",
		["icon"] = 1,
	}, -- [7]
	{
		["type"] = "f",
		["name"] = "BEAR_TANK_AUX1",
		["ID"] = 8,
		["text"] = "# Enter macro text here.\n/cast [nomod] mangle (bear)",
		["icon"] = 1,
	}, -- [8]
	{
		["type"] = "f",
		["name"] = "BLOOD_TURBO",
		["ID"] = 9,
		["text"] = "# Enter macro text here.\n/cast [mod:ctrl] acherus deathcharger",
		["icon"] = 1,
	}, -- [9]
	{
		["type"] = "f",
		["name"] = "BEAR_TANK_SHEAL",
		["ID"] = 10,
		["text"] = "/cast frenzied regeneration\n/cast survival instincts",
		["icon"] = 1,
	}, -- [10]
	[34] = {
		["type"] = "f",
		["name"] = "ELE_MULTI",
		["ID"] = 34,
		["text"] = "/startattack [nomod]\n/castsequence  [nomod,nochanneling] reset=combat call of the elements,chain lightning,lightning bolt,,,chain lightning,lightning bolt,,,chain lightning,lightning bolt,,,chain lightning,lightning bolt,,,chain lightning,lightning bolt,,,chain lightning,lightning bolt,,,chain lightning,lightning bolt,,,chain lightning,lightning bolt,,,chain lightning,lightning bolt,,,chain lightning,lightning bolt,,,chain lightning,lightning bolt,,,chain lightning,lightning bolt,,,chain lightning,lightning bolt,,,chain lightning,lightning bolt,,,chain lightning,lightning bolt,,,\n/cast nature's swiftness",
		["icon"] = 1,
	},
	[36] = {
		["type"] = "f",
		["name"] = "ELE_TURBO",
		["ID"] = 36,
		["text"] = "/castsequence reset=10  [mod:alt,nocombat] totemic recall,nil\n/cast [nomod,combat] elemental mastery\n/cast [nomod,combat] bloodlust\n/cast [mod:ctrl] great gray kodo",
		["icon"] = 1,
	},
	[38] = {
		["type"] = "f",
		["name"] = "ELE_AUX2",
		["ID"] = 38,
		["text"] = "# Enter macro text here.\n/castsequence [nochanneling] ,lightning bolt\n",
		["icon"] = 1,
	},
	[40] = {
		["type"] = "f",
		["name"] = "ELE_SETUP",
		["ID"] = 40,
		["text"] = "# Enter macro text here.\n/castsequence [nomod] reset=10 water shield",
		["icon"] = 1,
	},
	[42] = {
		["type"] = "f",
		["name"] = "ELE_SHEAL",
		["ID"] = 42,
		["text"] = "/cast [@player] lesser healing wave\n/cast [combat] earth elemental totem",
		["icon"] = 1,
	},
	[33] = {
		["type"] = "f",
		["name"] = "ELE_SINGLE",
		["ID"] = 33,
		["text"] = "# Enter macro text here.\n/startattack [nomod]\n/castsequence  [nochanneling] reset=combat call of the elements, flame shock, lightning bolt,,,lightning bolt,,,lightning bolt,,,flame shock, lightning bolt,,,lightning bolt,,,lightning bolt,,,flame shock, lightning bolt,,,lightning bolt,,,lightning bolt,,,flame shock, lightning bolt,,,lightning bolt,,,lightning bolt,,,flame shock, lightning bolt,,,lightning bolt,,,lightning bolt,,,flame shock, lightning bolt,,,lightning bolt,,,lightning bolt,,,\n/cast nature's swiftness",
		["icon"] = 1,
	},
	[35] = {
		["type"] = "f",
		["name"] = "ELE_AOE",
		["ID"] = 35,
		["text"] = "/startattack [nomod]\n/castsequence  [nochanneling] reset=combat magma totem, fire nova, chain lightning,lightning bolt, fire nova,chain lightning,lightning bolt, fire nova,chain lightning,lightning bolt, fire nova,chain lightning,lightning bolt, fire nova,chain lightning,lightning bolt, fire nova,chain lightning,lightning bolt, fire nova,chain lightning,lightning bolt, fire nova\n/cast nature's swiftness",
		["icon"] = 1,
	},
	[37] = {
		["type"] = "f",
		["name"] = "ELE_AUX1",
		["ID"] = 37,
		["text"] = "# Enter macro text here.\n/cast [nochanneling] earth shock",
		["icon"] = 1,
	},
	[39] = {
		["type"] = "f",
		["name"] = "ELE_AUX3",
		["ID"] = 39,
		["text"] = "/castsequence [nochanneling] reset=combat flame shock, earth shock, earth shock, earth shock",
		["icon"] = 1,
	},
	[41] = {
		["type"] = "f",
		["name"] = "ELE_INT",
		["ID"] = 41,
		["text"] = "# Enter macro text here.",
		["icon"] = 1,
	},
	[0] = {
		["type"] = "f",
		["name"] = "BLOOD_SINGLE",
		["ID"] = 0,
		["text"] = "# Enter macro text here.\n/startattack [nomod]\n/castsequence reset=combat blood strike,icy touch, plague strike",
		["icon"] = 1,
	},
}
