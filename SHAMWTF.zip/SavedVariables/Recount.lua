
RecountDB = {
	["profileKeys"] = {
		["Jealousy - LichKingMBW"] = "Jealousy - LichKingMBW",
		["Deathstrike - LichKingMBW"] = "Deathstrike - LichKingMBW",
		["Yogi - LichKingMBW"] = "Yogi - LichKingMBW",
		["Furyswipes - LichKingMBW"] = "Furyswipes - LichKingMBW",
	},
	["profiles"] = {
		["Jealousy - LichKingMBW"] = {
			["GraphWindowY"] = 0,
			["MainWindow"] = {
				["Position"] = {
					["h"] = 200.0000027354896,
					["w"] = 140.0000106684094,
				},
			},
			["ConfirmDeleteInstance"] = false,
			["Colors"] = {
				["Bar"] = {
					["Bar Text"] = {
						["a"] = 1,
					},
					["Total Bar"] = {
						["a"] = 1,
					},
				},
			},
			["DetailWindowY"] = 0,
			["ConfirmDeleteGroup"] = false,
			["DetailWindowX"] = 0,
			["GraphWindowX"] = 0,
			["MainWindowVis"] = false,
			["LastInstanceName"] = "Auchindoun: Mana-Tombs",
			["ConfirmDeleteRaid"] = false,
			["CurDataSet"] = "OverallData",
		},
		["Deathstrike - LichKingMBW"] = {
			["GraphWindowY"] = 0,
			["MainWindow"] = {
				["Position"] = {
					["y"] = -301.4999890238481,
					["x"] = 656.8333975375534,
					["w"] = 198.9999952812805,
					["h"] = 147.0000103264732,
				},
			},
			["DetailWindowX"] = 0,
			["MainWindowHeight"] = 146.5130581672453,
			["ConfirmDeleteRaid"] = false,
			["MainWindowMode"] = 2,
			["CurDataSet"] = "LastFightData",
			["Colors"] = {
				["Bar"] = {
					["Bar Text"] = {
						["a"] = 1,
					},
					["Total Bar"] = {
						["a"] = 1,
					},
				},
			},
			["DetailWindowY"] = 0,
			["GraphWindowX"] = 0,
			["ConfirmDeleteGroup"] = false,
			["MainWindowWidth"] = 199.1596078155946,
			["ConfirmDeleteInstance"] = false,
		},
		["Yogi - LichKingMBW"] = {
			["GraphWindowY"] = 0,
			["MainWindow"] = {
				["Position"] = {
					["y"] = -283.9999898786886,
					["h"] = 182.0000086167922,
					["w"] = 208.0000098477625,
					["x"] = 632.33342499503,
				},
			},
			["DetailWindowX"] = 0,
			["LastInstanceName"] = "Hellfire Citadel: Ramparts",
			["ConfirmDeleteRaid"] = false,
			["DetailWindowY"] = 0,
			["ConfirmDeleteInstance"] = false,
			["Colors"] = {
				["Bar"] = {
					["Bar Text"] = {
						["a"] = 1,
					},
					["Total Bar"] = {
						["a"] = 1,
					},
				},
			},
			["GraphWindowX"] = 0,
			["CurDataSet"] = "LastFightData",
			["ConfirmDeleteGroup"] = false,
			["MainWindowWidth"] = 208.123295080475,
			["MainWindowHeight"] = 181.5561852804537,
		},
		["Furyswipes - LichKingMBW"] = {
			["GraphWindowY"] = 0,
			["MainWindow"] = {
				["Position"] = {
					["y"] = -214.4091787711511,
					["h"] = 151.1239206185544,
					["w"] = 202.7450512087069,
					["x"] = 601.4560239617946,
				},
			},
			["DetailWindowX"] = 0,
			["MainWindowHeight"] = 151.1239206185544,
			["CurDataSet"] = "LastFightData",
			["Colors"] = {
				["Bar"] = {
					["Bar Text"] = {
						["a"] = 1,
					},
				},
			},
			["DetailWindowY"] = 0,
			["MainWindowMode"] = 2,
			["MainWindowWidth"] = 202.7449811801736,
			["GraphWindowX"] = 0,
		},
	},
}
