
ZygorGuidesViewerSettings = {
	["char"] = {
		["Deathstrike - LichKingMBW"] = {
			["debuglog"] = {
				"22:48:59> CacheQuestLog cached 0 quests", -- [1]
				"22:48:59> Lost Quest: Bloody Breakout, id: 12727, complete: false", -- [2]
				"22:49:19> CacheQuestLog cached 1 quests", -- [3]
				"22:49:19> New Quest: A Cry For Vengeance! id 12738", -- [4]
				"22:52:59> Viewer started. ---------------------------", -- [5]
				"22:52:59> PLAYER_ENTERING_WORLD (dead?)", -- [6]
				"22:52:59> CacheQuestLog cached 1 quests", -- [7]
				"22:52:59> New Quest: A Cry For Vengeance! id 12738", -- [8]
				"22:53:00> Got completed quests list", -- [9]
				"22:53:00> CacheQuestLog cached 1 quests", -- [10]
				"22:53:01> Guides loaded. -----", -- [11]
				"22:53:01> SetGuide Zygor's Horde Leveling Guides\\Death Knight (55-60) (141", -- [12]
				"22:53:01> Guide loaded: Zygor's Horde Leveling Guides\\Death Knight (55-60)", -- [13]
				"22:53:01> FocusStep 141", -- [14]
				"22:53:01> unpausing", -- [15]
				"22:53:01> frameNeedsUpdating, so updating.", -- [16]
				"22:55:45> Viewer started. ---------------------------", -- [17]
				"22:55:45> PLAYER_ENTERING_WORLD (dead?)", -- [18]
				"22:55:45> CacheQuestLog cached 1 quests", -- [19]
				"22:55:45> New Quest: A Cry For Vengeance! id 12738", -- [20]
				"22:55:46> Got completed quests list", -- [21]
				"22:55:46> CacheQuestLog cached 1 quests", -- [22]
				"22:55:47> Guides loaded. -----", -- [23]
				"22:55:47> SetGuide Zygor's Horde Leveling Guides\\Death Knight (55-60) (141", -- [24]
				"22:55:47> Guide loaded: Zygor's Horde Leveling Guides\\Death Knight (55-60)", -- [25]
				"22:55:47> FocusStep 141", -- [26]
				"22:55:47> unpausing", -- [27]
				"22:55:47> frameNeedsUpdating, so updating.", -- [28]
				"22:55:55> Viewer started. ---------------------------", -- [29]
				"22:55:55> PLAYER_ENTERING_WORLD (dead?)", -- [30]
				"22:55:55> CacheQuestLog cached 1 quests", -- [31]
				"22:55:55> New Quest: A Cry For Vengeance! id 12738", -- [32]
				"22:55:56> Got completed quests list", -- [33]
				"22:55:56> CacheQuestLog cached 1 quests", -- [34]
				"22:55:57> Guides loaded. -----", -- [35]
				"22:55:57> SetGuide Zygor's Horde Leveling Guides\\Death Knight (55-60) (141", -- [36]
				"22:55:57> Guide loaded: Zygor's Horde Leveling Guides\\Death Knight (55-60)", -- [37]
				"22:55:57> FocusStep 141", -- [38]
				"22:55:57> unpausing", -- [39]
				"22:55:57> frameNeedsUpdating, so updating.", -- [40]
				"22:57:50> Viewer started. ---------------------------", -- [41]
				"22:57:50> PLAYER_ENTERING_WORLD (dead?)", -- [42]
				"22:57:50> CacheQuestLog cached 1 quests", -- [43]
				"22:57:50> New Quest: A Cry For Vengeance! id 12738", -- [44]
				"22:57:50> Got completed quests list", -- [45]
				"22:57:50> CacheQuestLog cached 1 quests", -- [46]
				"22:57:51> Guides loaded. -----", -- [47]
				"22:57:51> SetGuide Zygor's Horde Leveling Guides\\Death Knight (55-60) (141", -- [48]
				"22:57:51> Guide loaded: Zygor's Horde Leveling Guides\\Death Knight (55-60)", -- [49]
				"22:57:51> FocusStep 141", -- [50]
				"22:57:51> unpausing", -- [51]
				"22:57:51> frameNeedsUpdating, so updating.", -- [52]
				"22:58:11> Viewer started. ---------------------------", -- [53]
				"22:58:12> PLAYER_ENTERING_WORLD (dead?)", -- [54]
				"22:58:12> CacheQuestLog cached 1 quests", -- [55]
				"22:58:12> New Quest: A Cry For Vengeance! id 12738", -- [56]
				"22:58:12> Got completed quests list", -- [57]
				"22:58:12> CacheQuestLog cached 1 quests", -- [58]
				"22:58:13> Guides loaded. -----", -- [59]
				"22:58:13> SetGuide Zygor's Horde Leveling Guides\\Death Knight (55-60) (141", -- [60]
				"22:58:13> Guide loaded: Zygor's Horde Leveling Guides\\Death Knight (55-60)", -- [61]
				"22:58:13> FocusStep 141", -- [62]
				"22:58:13> unpausing", -- [63]
				"22:58:13> frameNeedsUpdating, so updating.", -- [64]
				"22:58:27> Viewer started. ---------------------------", -- [65]
				"22:58:28> PLAYER_ENTERING_WORLD (dead?)", -- [66]
				"22:58:28> CacheQuestLog cached 1 quests", -- [67]
				"22:58:28> New Quest: A Cry For Vengeance! id 12738", -- [68]
				"22:58:28> Got completed quests list", -- [69]
				"22:58:28> CacheQuestLog cached 1 quests", -- [70]
				"22:58:29> Guides loaded. -----", -- [71]
				"22:58:29> SetGuide Zygor's Horde Leveling Guides\\Death Knight (55-60) (141", -- [72]
				"22:58:29> Guide loaded: Zygor's Horde Leveling Guides\\Death Knight (55-60)", -- [73]
				"22:58:29> FocusStep 141", -- [74]
				"22:58:29> unpausing", -- [75]
				"22:58:29> frameNeedsUpdating, so updating.", -- [76]
				"22:59:32> Viewer started. ---------------------------", -- [77]
				"22:59:33> PLAYER_ENTERING_WORLD (dead?)", -- [78]
				"22:59:33> CacheQuestLog cached 1 quests", -- [79]
				"22:59:33> New Quest: A Cry For Vengeance! id 12738", -- [80]
				"22:59:33> Got completed quests list", -- [81]
				"22:59:33> CacheQuestLog cached 1 quests", -- [82]
				"22:59:34> Guides loaded. -----", -- [83]
				"22:59:34> SetGuide Zygor's Horde Leveling Guides\\Death Knight (55-60) (141", -- [84]
				"22:59:34> Guide loaded: Zygor's Horde Leveling Guides\\Death Knight (55-60)", -- [85]
				"22:59:34> FocusStep 141", -- [86]
				"22:59:34> unpausing", -- [87]
				"22:59:34> frameNeedsUpdating, so updating.", -- [88]
				"22:59:42> Viewer started. ---------------------------", -- [89]
				"22:59:42> PLAYER_ENTERING_WORLD (dead?)", -- [90]
				"22:59:42> CacheQuestLog cached 1 quests", -- [91]
				"22:59:42> New Quest: A Cry For Vengeance! id 12738", -- [92]
				"22:59:42> Got completed quests list", -- [93]
				"22:59:42> CacheQuestLog cached 1 quests", -- [94]
				"22:59:43> Guides loaded. -----", -- [95]
				"22:59:43> SetGuide Zygor's Horde Leveling Guides\\Death Knight (55-60) (141", -- [96]
				"22:59:43> Guide loaded: Zygor's Horde Leveling Guides\\Death Knight (55-60)", -- [97]
				"22:59:43> FocusStep 141", -- [98]
				"22:59:43> unpausing", -- [99]
				"22:59:43> frameNeedsUpdating, so updating.", -- [100]
			},
			["guidename"] = "Zygor's Horde Leveling Guides\\Death Knight (55-60)",
			["step"] = 141,
			["RecipesKnown"] = {
				[53341] = true,
				[53343] = true,
			},
			["maint_fetchitemdata"] = true,
			["guides_history"] = {
				{
					["short"] = "Death Knight (55-60)",
					["full"] = "Zygor's Horde Leveling Guides\\Death Knight (55-60)",
					["step"] = 141,
				}, -- [1]
			},
			["maint_fetchquestdata"] = true,
			["taxis"] = {
			},
			["starting"] = false,
		},
		["Furyswipes - LichKingMBW"] = {
			["maint_fetchitemdata"] = true,
			["step"] = 160,
			["guides_history"] = {
				{
					["short"] = "Tauren (1-13)",
					["full"] = "Zygor's Horde Leveling Guides\\Tauren (1-13)",
					["step"] = 160,
				}, -- [1]
			},
			["maint_fetchquestdata"] = true,
			["guidename"] = "Zygor's Horde Leveling Guides\\Tauren (1-13)",
			["taxis"] = {
			},
			["debuglog"] = {
				"14:35:39> frameNeedsUpdating, so updating.", -- [1]
				"14:35:39> Skipping step: 150 (impossible)", -- [2]
				"14:35:39> SkipStep 1 fast", -- [3]
				"14:35:39> LastSkip 1", -- [4]
				"14:35:39> FocusStep 151 (quiet)", -- [5]
				"14:35:39> FocusStep 151", -- [6]
				"14:35:39> frameNeedsUpdating, so updating.", -- [7]
				"14:35:39> Skipping step: 151 (possible?)", -- [8]
				"14:35:39> SkipStep 1 fast", -- [9]
				"14:35:39> LastSkip 1", -- [10]
				"14:35:39> FocusStep 152 (quiet)", -- [11]
				"14:35:39> FocusStep 152", -- [12]
				"14:35:39> Missing from NPC database: Arra'chea #3058", -- [13]
				"14:35:39> frameNeedsUpdating, so updating.", -- [14]
				"14:35:39> Skipping step: 152 (impossible)", -- [15]
				"14:35:39> SkipStep 1 fast", -- [16]
				"14:35:39> LastSkip 1", -- [17]
				"14:35:39> FocusStep 153 (quiet)", -- [18]
				"14:35:39> FocusStep 153", -- [19]
				"14:35:39> Missing from NPC database: Ghost Howl #3056", -- [20]
				"14:35:39> frameNeedsUpdating, so updating.", -- [21]
				"14:35:39> Skipping step: 153 (impossible)", -- [22]
				"14:35:39> SkipStep 1 fast", -- [23]
				"14:35:39> LastSkip 1", -- [24]
				"14:35:39> FocusStep 154 (quiet)", -- [25]
				"14:35:39> FocusStep 154", -- [26]
				"14:35:39> frameNeedsUpdating, so updating.", -- [27]
				"14:35:39> Skipping step: 154 (possible?)", -- [28]
				"14:35:39> SkipStep 1 fast", -- [29]
				"14:35:39> LastSkip 1", -- [30]
				"14:35:39> FocusStep 155 (quiet)", -- [31]
				"14:35:39> FocusStep 155", -- [32]
				"14:35:39> Translated: accept/turnin Rites of the Earthmother", -- [33]
				"14:35:39> frameNeedsUpdating, so updating.", -- [34]
				"14:35:39> Skipping step: 155 (impossible)", -- [35]
				"14:35:39> SkipStep 1 fast", -- [36]
				"14:35:39> LastSkip 1", -- [37]
				"14:35:39> FocusStep 156 (quiet)", -- [38]
				"14:35:39> FocusStep 156", -- [39]
				"14:35:39> frameNeedsUpdating, so updating.", -- [40]
				"14:35:39> Skipping step: 156 (possible?)", -- [41]
				"14:35:39> SkipStep 1 fast", -- [42]
				"14:35:39> LastSkip 1", -- [43]
				"14:35:39> FocusStep 157 (quiet)", -- [44]
				"14:35:39> FocusStep 157", -- [45]
				"14:35:39> Translated: accept/turnin The Demon Scarred Cloak", -- [46]
				"14:35:40> frameNeedsUpdating, so updating.", -- [47]
				"14:35:40> Skipping step: 157 (impossible)", -- [48]
				"14:35:40> SkipStep 1 fast", -- [49]
				"14:35:40> LastSkip 1", -- [50]
				"14:35:40> FocusStep 158 (quiet)", -- [51]
				"14:35:40> FocusStep 158", -- [52]
				"14:35:40> frameNeedsUpdating, so updating.", -- [53]
				"14:35:40> Skipping step: 158 (complete)", -- [54]
				"14:35:40> SkipStep 1 fast", -- [55]
				"14:35:40> LastSkip 1", -- [56]
				"14:35:40> FocusStep 159 (quiet)", -- [57]
				"14:35:40> FocusStep 159", -- [58]
				"14:35:40> Translated: accept/turnin Wildmane Cleansing", -- [59]
				"14:35:40> frameNeedsUpdating, so updating.", -- [60]
				"14:35:40> Skipping step: 159 (impossible)", -- [61]
				"14:35:40> SkipStep 1 fast", -- [62]
				"14:35:40> LastSkip 1", -- [63]
				"14:35:40> FocusStep 160 (quiet)", -- [64]
				"14:35:40> FocusStep 160", -- [65]
				"14:35:40> frameNeedsUpdating, so updating.", -- [66]
				"14:37:44> Translated: accept/turnin Sergra Darkthorn", -- [67]
				"14:37:44> frameNeedsUpdating, so updating.", -- [68]
				"14:42:25> Viewer started. ---------------------------", -- [69]
				"14:42:25> PLAYER_ENTERING_WORLD (dead?)", -- [70]
				"14:42:25> CacheQuestLog cached 0 quests", -- [71]
				"14:42:25> Got completed quests list", -- [72]
				"14:42:25> CacheQuestLog cached 0 quests", -- [73]
				"14:42:27> Guides loaded. -----", -- [74]
				"14:42:27> SetGuide Zygor's Horde Leveling Guides\\Tauren (1-13) (160", -- [75]
				"14:42:27> Guide loaded: Zygor's Horde Leveling Guides\\Tauren (1-13)", -- [76]
				"14:42:27> FocusStep 160", -- [77]
				"14:42:27> Translated: accept/turnin The Hunt Begins", -- [78]
				"14:42:27> Translated: accept/turnin A Humble Task", -- [79]
				"14:42:27> unpausing", -- [80]
				"14:42:27> Error in step height calculation! step 2 stepbottom=nil scrollbottom=nil, forcing update", -- [81]
				"14:42:27> Error in step height calculation! step 2 stepbottom=nil scrollbottom=380.13543162709, forcing update", -- [82]
				"14:42:27> frameNeedsUpdating, so updating.", -- [83]
				"14:42:27> Error in step height calculation! step 2 stepbottom=nil scrollbottom=380.13543162709, forcing update", -- [84]
				"14:42:27> frameNeedsUpdating, so updating.", -- [85]
				"14:42:34> Viewer started. ---------------------------", -- [86]
				"14:42:34> PLAYER_ENTERING_WORLD (dead?)", -- [87]
				"14:42:34> CacheQuestLog cached 0 quests", -- [88]
				"14:42:34> Got completed quests list", -- [89]
				"14:42:34> CacheQuestLog cached 0 quests", -- [90]
				"14:42:36> Guides loaded. -----", -- [91]
				"14:42:36> SetGuide Zygor's Horde Leveling Guides\\Tauren (1-13) (160", -- [92]
				"14:42:36> Guide loaded: Zygor's Horde Leveling Guides\\Tauren (1-13)", -- [93]
				"14:42:36> FocusStep 160", -- [94]
				"14:42:36> Translated: accept/turnin The Hunt Begins", -- [95]
				"14:42:36> Translated: accept/turnin A Humble Task", -- [96]
				"14:42:36> unpausing", -- [97]
				"14:42:36> Error in step height calculation! step 2 stepbottom=nil scrollbottom=nil, forcing update", -- [98]
				"14:42:36> Error in step height calculation! step 2 stepbottom=nil scrollbottom=380.13543162709, forcing update", -- [99]
				"14:42:36> frameNeedsUpdating, so updating.", -- [100]
			},
			["starting"] = false,
		},
	},
	["profileKeys"] = {
		["Deathstrike - LichKingMBW"] = "Deathstrike - LichKingMBW",
		["Furyswipes - LichKingMBW"] = "Furyswipes - LichKingMBW",
	},
	["profiles"] = {
		["Deathstrike - LichKingMBW"] = {
			["arrowsmooth"] = true,
			["autoturnin"] = true,
			["arrowposx"] = 925.5351553836727,
			["autoaccept"] = true,
			["arrowcam"] = false,
			["arrowposy"] = 883.6311315400512,
			["analyzereps"] = true,
			["contractmobs"] = true,
		},
		["Furyswipes - LichKingMBW"] = {
			["arrowsmooth"] = true,
			["fullheight"] = 120.8645564051454,
			["windowlocked"] = false,
			["contractmobs"] = true,
			["arrowcam"] = false,
			["showallsteps"] = true,
		},
	},
}
