
GS_Settings = {
	["Show"] = 1,
	["Player"] = 1,
	["Item"] = 1,
	["Compare"] = -1,
	["Special"] = 1,
	["Average"] = -1,
	["Level"] = -1,
}
