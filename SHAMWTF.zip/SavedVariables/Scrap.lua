
Scrap_AutoSell = nil
Scrap_Tutorials = true
