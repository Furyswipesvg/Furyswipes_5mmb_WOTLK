
EavesDropDB = {
	["profileKeys"] = {
		["Yogi - LichKingMBW"] = "Yogi - LichKingMBW",
	},
	["profiles"] = {
		["Yogi - LichKingMBW"] = {
			["y"] = 56.78395353421331,
			["x"] = 467.1372145635509,
		},
	},
}
