
ThreatPlates3DB = {
	["char"] = {
		["Jealousy - LichKingMBW"] = {
			["welcome"] = true,
			["specName"] = {
				"Elemental", -- [1]
				"Enhancement", -- [2]
				"Restoration", -- [3]
			},
			["spec"] = {
				["primary"] = false,
			},
			["specInfo"] = {
				{
					36, -- [1]
					[3] = 21,
				}, -- [1]
			},
		},
	},
	["profileKeys"] = {
		["Jealousy - LichKingMBW"] = "Default",
	},
	["profiles"] = {
		["Default"] = {
		},
	},
}
