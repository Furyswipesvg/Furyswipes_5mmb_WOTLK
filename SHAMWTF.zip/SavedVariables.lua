
CHANNELPULLOUT_OPTIONS = {
	["displayActive"] = true,
	["name"] = "Channel Roster",
}
