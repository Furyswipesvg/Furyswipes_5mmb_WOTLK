
RAID_PULLOUT_POSITIONS = {
	["1"] = {
		["y"] = 799.5388730507841,
		["x"] = 72.90381286898763,
		["point"] = "TOP",
		["relativePoint"] = "BOTTOMLEFT",
		["settings"] = {
		},
	},
	["3"] = {
		["y"] = 801.4782432494443,
		["x"] = 168.516067069007,
		["point"] = "TOP",
		["relativePoint"] = "BOTTOMLEFT",
		["settings"] = {
		},
	},
	["2"] = {
		["y"] = 615.101503828557,
		["x"] = 72.90397480997066,
		["point"] = "TOP",
		["relativePoint"] = "BOTTOMLEFT",
		["settings"] = {
		},
	},
}
RAID_SINGLE_POSITIONS = {
}
