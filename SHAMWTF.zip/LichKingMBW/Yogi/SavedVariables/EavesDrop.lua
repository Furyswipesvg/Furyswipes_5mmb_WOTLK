
EavesDropStatsDB = {
	["profileKeys"] = {
		["Yogi - LichKingMBW"] = "Yogi - LichKingMBW",
	},
	["profiles"] = {
		["Yogi - LichKingMBW"] = {
			{
				["heal"] = {
					["Healing Touch"] = {
						[2] = {
							["time"] = "|cffffffff06/09/20 09:02:35|r\n|Hunit:0x00000000000000CC:Yogi|hYogi's|h |Hspell:25297:SPELL_HEAL|h|cffffffffHealing Touch|r|h heals |Hunit:0x00000000000000CC:Yogi|hYogi|h for |cffffffff0|r.(3030 Overhealed) (Critical)",
							["amount"] = 3030,
						},
						[-2] = {
							["time"] = "|cffffffff06/09/20 08:56:52|r\n|Hunit:0x00000000000000CC:Yogi|hYogi's|h |Hspell:25297:SPELL_HEAL|h|cffffffffHealing Touch|r|h heals |Hunit:0x00000000000000CC:Yogi|hYogi|h for |cffffffff0|r.(2220 Overhealed)",
							["amount"] = 2220,
						},
						["icon"] = "Interface\\Icons\\Spell_Nature_HealingTouch",
					},
					["Improved Leader of the Pack"] = {
						[2] = {
						},
						[-2] = {
							["time"] = "|cffffffff06/09/20 09:03:21|r\n|Hunit:0x00000000000000CC:Yogi|hYogi|h gains |cffffffff233|r Health from |Hunit:0x00000000000000CC:Yogi|hYogi's|h |Hspell:34299:SPELL_PERIODIC_HEAL|h|cffffffffImproved Leader of the Pack|r|h.",
							["amount"] = 233,
						},
						["icon"] = "Interface\\Icons\\Spell_Nature_UnyeildingStamina",
					},
					["Frenzied Regeneration"] = {
						[2] = {
						},
						[-2] = {
							["time"] = "|cffffffff06/09/20 09:03:18|r\n|Hunit:0x00000000000000CC:Yogi|hYogi's|h |Hspell:22845:SPELL_HEAL|h|cffffffffFrenzied Regeneration|r|h heals |Hunit:0x00000000000000CC:Yogi|hYogi|h for |cffffffff174|r.",
							["amount"] = 174,
						},
						["icon"] = "Interface\\Icons\\Ability_BullRush",
					},
				},
				["hit"] = {
					["Melee Attack"] = {
						[2] = {
							["time"] = "|cffffffff06/09/20 08:56:27|r\n|Hunit:0x00000000000000CC:Yogi|hYogi's|h melee swing hits |Hunit:0xF130004377301068:Bonechewer Destroyer|hBonechewer Destroyer|h for |cffffffff408|r |cffffffffPhysical|r.(Critical)",
							["amount"] = 408,
						},
						[-2] = {
							["time"] = "|cffffffff06/09/20 09:06:27|r\n|Hunit:0x00000000000000CC:Yogi|hYogi's|h melee swing hits |Hunit:0xF130004380301080:Shattered Hand Warhound|hShattered Hand Warhound|h for |cffffffff224|r |cffffffffPhysical|r.",
							["amount"] = 224,
						},
					},
					["Maul"] = {
						[2] = {
							["time"] = "|cffffffff06/09/20 08:50:40|r\n|Hunit:0x00000000000000CC:Yogi|hYogi's|h |Hspell:9881:SPELL_DAMAGE|h|cffffffffMaul|r|h hits |Hunit:0xF13000437530104E:Bleeding Hollow Darkcaster|hBleeding Hollow Darkcaster|h for |cffffffff1128|r |cffffffffPhysical|r.(Critical)",
							["amount"] = 1128,
						},
						[-2] = {
							["time"] = "|cffffffff06/09/20 08:51:00|r\n|Hunit:0x00000000000000CC:Yogi|hYogi's|h |Hspell:9881:SPELL_DAMAGE|h|cffffffffMaul|r|h hits |Hunit:0xF130004370301062:Bonechewer Ravener|hBonechewer Ravener|h for |cffffffff497|r |cffffffffPhysical|r.",
							["amount"] = 497,
						},
						["icon"] = "Interface\\Icons\\Ability_Druid_Maul",
					},
					["Mangle (Bear)"] = {
						[2] = {
							["time"] = "|cffffffff06/09/20 09:04:11|r\n|Hunit:0x00000000000000CC:Yogi|hYogi's|h |Hspell:33986:SPELL_DAMAGE|h|cffffffffMangle (Bear)|r|h hits |Hunit:0xF130004380301083:Shattered Hand Warhound|hShattered Hand Warhound|h for |cffffffff774|r |cffffffffPhysical|r.(Critical)",
							["amount"] = 774,
						},
						[-2] = {
							["time"] = "|cffffffff06/09/20 08:56:20|r\n|Hunit:0x00000000000000CC:Yogi|hYogi's|h |Hspell:33986:SPELL_DAMAGE|h|cffffffffMangle (Bear)|r|h hits |Hunit:0xF130004375301064:Bleeding Hollow Darkcaster|hBleeding Hollow Darkcaster|h for |cffffffff422|r |cffffffffPhysical|r.",
							["amount"] = 422,
						},
						["icon"] = "Interface\\Icons\\Ability_Druid_Mangle2",
					},
					["Faerie Fire (Feral)"] = {
						[2] = {
							["time"] = "|cffffffff06/09/20 09:05:38|r\n|Hunit:0x00000000000000CC:Yogi|hYogi's|h |Hspell:60089:SPELL_DAMAGE|h|cffffffffFaerie Fire (Feral)|r|h hits |Hunit:0xF13000436B30107D:Bonechewer Hungerer|hBonechewer Hungerer|h for |cffffffff90|r |cffffffffNature|r.(Critical)",
							["amount"] = 90,
						},
						[-2] = {
							["time"] = "|cffffffff06/09/20 09:03:09|r\n|Hunit:0x00000000000000CC:Yogi|hYogi's|h |Hspell:60089:SPELL_DAMAGE|h|cffffffffFaerie Fire (Feral)|r|h hits |Hunit:0xF13000436B30106D:Bonechewer Hungerer|hBonechewer Hungerer|h for |cffffffff99|r |cffffffffNature|r.",
							["amount"] = 99,
						},
						["icon"] = "Interface\\Icons\\Spell_Nature_FaerieFire",
					},
					["Thorns"] = {
						[2] = {
						},
						[-2] = {
							["time"] = "|cffffffff06/09/20 09:03:08|r\n|Hunit:0x00000000000000CC:Yogi|hYogi's|h |Hspell:9910:DAMAGE_SHIELD|h|cffffffffThorns|r|h reflects |cffffffff18|r |cffffffffNature|r damage to |Hunit:0xF13000436B30106D:Bonechewer Hungerer|hBonechewer Hungerer|h.",
							["amount"] = 18,
						},
						["icon"] = "Interface\\Icons\\Spell_Nature_Thorns",
					},
				},
			}, -- [1]
			[-1] = {
				["heal"] = {
					["Healing Touch"] = {
						[2] = {
							["time"] = "|cffffffff06/09/20 09:06:23|r\n|Hunit:0x00000000000000C0:Baloo|hBaloo's|h |Hspell:25297:SPELL_HEAL|h|cff82f4ffHealing Touch|r|h heals |Hunit:0x00000000000000CC:Yogi|hYogi|h for |cff82f4ff0|r.(3358 Overhealed) (Critical)",
							["amount"] = 3358,
						},
						[-2] = {
							["time"] = "|cffffffff06/09/20 08:56:52|r\n|Hunit:0x00000000000000BE:Rupert|hRupert's|h |Hspell:25297:SPELL_HEAL|h|cff82f4ffHealing Touch|r|h heals |Hunit:0x00000000000000CC:Yogi|hYogi|h for |cff82f4ff0|r.(2289 Overhealed)",
							["amount"] = 2289,
						},
						["icon"] = "Interface\\Icons\\Spell_Nature_HealingTouch",
					},
				},
				["hit"] = {
					["Physical"] = {
						[2] = {
						},
						["icon"] = "Interface\\Icons\\Ability_CriticalStrike",
						[-2] = {
							["time"] = "|cffffffff06/09/20 09:07:27|r\n|Hunit:0xF13000439A3010A5:Watchkeeper Gargolmar|hWatchkeeper Gargolmar's|h |Hspell:30641:SPELL_DAMAGE|h|cffff1313Mortal Wound|r|h hits |Hunit:0x00000000000000CC:Yogi|hYogi|h for |cffff1313673|r |cffff1313Physical|r.(581 Overkill)",
							["amount"] = 1254,
						},
					},
					["Shadow"] = {
						[2] = {
						},
						[-2] = {
							["time"] = "|cffffffff06/09/20 08:57:36|r\n|Hunit:0xF13000444630107C:Bleeding Hollow Scryer|hBleeding Hollow Scryer's|h |Hspell:12471:SPELL_DAMAGE|h|cffff1313Shadow Bolt|r|h hits |Hunit:0x00000000000000CC:Yogi|hYogi|h for |cffff1313465|r |cffff1313Shadow|r.",
							["amount"] = 465,
						},
						["icon"] = "Interface\\Icons\\Spell_Shadow_ShadowBolt",
					},
					["Fire"] = {
						[2] = {
						},
						[-2] = {
							["time"] = "|cffffffff06/09/20 09:03:30|r\n|Hunit:0x00000000000000CC:Yogi|hYogi|h suffers |cffff1313348|r |cffff1313Fire|r damage from |Hunit:0xF130004375301070:Bleeding Hollow Darkcaster|hBleeding Hollow Darkcaster's|h |Hspell:31598:SPELL_PERIODIC_DAMAGE|h|cffff1313Rain of Fire|r|h.",
							["amount"] = 348,
						},
						["icon"] = "Interface\\Icons\\Spell_Shadow_RainOfFire",
					},
				},
			},
		},
	},
}
