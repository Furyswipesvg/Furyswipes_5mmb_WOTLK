
TidyPlatesOptions = {
	["secondary"] = "Neon/DPS",
	["primary"] = "Neon/Tank",
}
